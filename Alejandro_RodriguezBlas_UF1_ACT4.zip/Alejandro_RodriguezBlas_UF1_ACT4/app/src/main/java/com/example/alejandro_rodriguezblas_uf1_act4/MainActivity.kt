package com.example.alejandro_rodriguezblas_uf1_act4

import android.app.Notification.Action
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.Toast

class MainActivity : AppCompatActivity() {

    lateinit var logCatButon: Button
    lateinit var toastButton: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        logCatButon = findViewById(R.id.logCatButton)
        toastButton = findViewById(R.id.toastButton)

        logCatButon.setOnClickListener {
            Log.d("logCatMensaje", getString(R.string.LogCatButtonString));
        }
        toastButton.setOnClickListener {
            val duration = Toast.LENGTH_SHORT;
            val toast = Toast.makeText(this,getString(R.string.ToastButtonString),duration)
            toast.show()
        }
    }




}

